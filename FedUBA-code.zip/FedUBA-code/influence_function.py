import torch
from torch.autograd import grad


# calculate the influence function sort
def influence_sort_function(x_test, y_test, dataloader, model, FL_params):

    gpu = -1 if FL_params.device=='cpu' else 1
    
    # calculate s_test
    h_e = s_test(x_test, y_test, model.to(FL_params.device), dataloader, gpu)
    
    # calculate the influence function
    influence = []
    for i in range(len(dataloader.dataset)):
        
        if i % 100 == 0:
            print(f"Processing sample {i+1}/{len(dataloader.dataset)}")

        if gpu >= 0:
            torch.cuda.empty_cache()
            
        x, y = dataloader.dataset[i]
        if gpu >= 0:
            x, y = x.unsqueeze(0).cuda(), torch.tensor([y]).cuda()
        else:
            x, y = x.unsqueeze(0), torch.tensor([y])
            
        # calculate the gradient
        grad_temp = grad_z(x, y, model, gpu)
        
        # calculate the inner product
        inner_product = 0
        for gt, he in zip(grad_temp, h_e):
            if gt is not None and he is not None:
                inner_product += torch.sum(gt * he)
                
        influence.append(inner_product.cpu())
        
        # delete the temporary variables to save memory
        del grad_temp, x, y
        if gpu >= 0:
            torch.cuda.empty_cache()
    
    # sort the influence function
    influence = torch.stack(influence)
    influence = influence.numpy()
    influence = influence.argsort()
    
    
    return influence
    


def s_test(z_test, t_test, model, z_loader, gpu=-1, damp=0.01, scale=25.0,
           recursion_depth=2500):
    """s_test can be precomputed for each test point of interest, and then
    multiplied with grad_z to get the desired value for each training point.
    Here, strochastic estimation is used to calculate s_test. s_test is the
    Inverse Hessian Vector Product.

    Arguments:
        z_test: torch tensor, test data points, such as test images
        t_test: torch tensor, contains all test data labels
        model: torch NN, model used to evaluate the dataset
        z_loader: torch Dataloader, can load the training dataset
        gpu: int, GPU id to use if >=0 and -1 means use CPU
        damp: float, dampening factor
        scale: float, scaling factor
        recursion_depth: int, number of iterations aka recursion depth
            should be enough so that the value stabilises.

    Returns:
        h_estimate: list of torch tensors, s_test"""
    

    # compute the gradient of z_test
    v = grad_z(z_test, t_test, model, gpu)
    h_estimate = v.copy()


    for i in range(recursion_depth):
        # take just one random sample from training dataset
        # easiest way to just use the DataLoader once, break at the end of loop
        for x, t in z_loader:
            if gpu >= 0:
                x, t = x.cuda(), t.cuda()
            y = model(x)
            loss = calc_loss(y, t)
            params = [ p for p in model.parameters() if p.requires_grad ]
            hv = hvp(loss, params, h_estimate)
            # Recursively caclulate h_estimate

            h_estimate = [
                _v + (1 - damp) * _h_e - _hv / scale
                for _v, _h_e, _hv in zip(v, h_estimate, hv)]
             # process the NaN values
            for j, _h_e in enumerate(h_estimate):
                if _h_e is not None and torch.isnan(_h_e).any():
                    nan_count = torch.isnan(_h_e).sum().item()
                    h_estimate[j] = torch.nan_to_num(_h_e, nan=0.0)

            break

        # print the recursion depth
        if i % 100 == 0:
            print("Calc. s_test recursions: ", i, recursion_depth)

    
    return h_estimate


def calc_loss(y, t):
    """Calculates the loss

    Arguments:
        y: torch tensor, input with size (minibatch, nr_of_classes)
        t: torch tensor, target expected by loss of size (0 to nr_of_classes-1)

    Returns:
        loss: scalar, the loss"""


    y = torch.nn.functional.log_softmax(y)
    loss = torch.nn.functional.nll_loss(
        y, t, weight=None, reduction='mean')
    return loss


def grad_z(z, t, model, gpu=-1):

    model.eval()
    

    if gpu >= 0:
        torch.cuda.empty_cache()
    

    if gpu >= 0:
        z, t = z.cuda(), t.cuda()
    

    with torch.no_grad():
        y = model(z)
        loss = calc_loss(y, t)
        

    params = [p for p in model.parameters() if p.requires_grad]
    

    y = model(z)
    loss = calc_loss(y, t)
    

    grads = grad(loss, params, create_graph=False, retain_graph=False)
    

    grads = [g.clone().detach() if g is not None else None for g in grads]
    
    return list(grads)



def hvp(y, w, v):

    if len(w) != len(v):
        raise(ValueError("w and v must have the same length."))


    epsilon = 1e-4
    

    w_backup = [p.clone().detach() for p in w]
    

    grads_orig = grad(y, w, retain_graph=True)
    grads_orig = [g.clone().detach() for g in grads_orig]
    

    for p, v_p in zip(w, v):
        p.data.add_(epsilon * v_p)
    

    grads_pert = grad(y, w, retain_graph=True)
    

    for p, p_orig in zip(w, w_backup):
        p.data.copy_(p_orig)

    return_grads = [(g_p - g_o) / epsilon for g_p, g_o in zip(grads_pert, grads_orig)]
    
    return return_grads