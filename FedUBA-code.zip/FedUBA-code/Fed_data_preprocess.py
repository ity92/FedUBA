# -*- coding: utf-8 -*-

import torch
from torch.utils.data import DataLoader
import numpy as np
from torchvision import datasets, transforms

import os

"""Function: load data"""
def data_init(FL_params):

    # newly created path to save the segmented dataset
    data_path = f"./{FL_params.model_result_name}/{FL_params.data_name}"
    client_dataset_path = f'{data_path}/{FL_params.data_name}_client_dataset.pth'

    if not os.path.exists(data_path):
        os.makedirs(data_path)
    
    kwargs = {'num_workers': 0, 'pin_memory': True} if "cuda" in FL_params.device else {}
    
    trainset, testset = data_set(FL_params.data_name)

    # Build a test data loader
    test_loader = DataLoader(testset, batch_size=FL_params.test_batch_size, shuffle=False, **kwargs)

    # Evenly distribute the data into N-client copies according to the training trainset, and save all the segmented datasets in a list
    if not os.path.exists(client_dataset_path):
        # split the dataset into N_client subsets
        split_index = [int(trainset.__len__()/FL_params.N_total_client)]*(FL_params.N_total_client-1)
        split_index.append(int(trainset.__len__() - int(trainset.__len__()/FL_params.N_total_client)*(FL_params.N_total_client-1)))
        client_dataset = torch.utils.data.random_split(trainset, split_index)
        # save the segmented dataset
        torch.save(client_dataset, client_dataset_path)

    else: 
        client_dataset = torch.load(client_dataset_path)
    

    client_loaders = []
    for ii in range(FL_params.N_total_client):
        client_loaders.append(DataLoader(client_dataset[ii], FL_params.local_batch_size, shuffle=True, **kwargs))

        '''
        By now, we have separated the local data of the client user and stored it in client_loaders.
        Each corresponds to a user's private data
        '''
    
    return client_loaders, test_loader


def data_init_non_iid(FL_params):

    # newly created path to save the segmented dataset
    data_path = f"./{FL_params.model_result_name}/{FL_params.data_name}"
    client_dataset_path = f'{data_path}/{FL_params.data_name}_nonIID_client_dataset.pth'

    if not os.path.exists(data_path):
        os.makedirs(data_path)

    import matplotlib.pyplot as plt
    kwargs = {'num_workers': 0, 'pin_memory': True} if "cuda" in FL_params.device else {}
    
    trainset, testset = data_set(FL_params.data_name)

    # Build a test data loader
    test_loader = DataLoader(testset, batch_size=FL_params.test_batch_size, shuffle=False, **kwargs)

    if not os.path.exists(client_dataset_path):
        # non-iid split
        classes = trainset.classes
        n_classes = len(classes)
        n_clients=FL_params.N_total_client

        labels = np.concatenate(
            [np.array(trainset.targets), np.array(testset.targets)], axis=0)


        client_sample_nums = balance_split(n_clients, len(trainset))
        client_idcs_dict = client_inner_dirichlet_partition(trainset.targets, n_clients, n_classes, dir_alpha=1, client_sample_nums=client_sample_nums, verbose=False)
        
        client_idcs = []
        for _ in client_idcs_dict.values():
            client_idcs.append(_)


        client_dataset = [torch.utils.data.Subset(trainset, indices) for indices in client_idcs]

        # This section describes how different labels are assigned to different clients
        plt.figure(figsize=(12, 8))
        label_distribution = [[] for _ in range(n_classes)]
        for c_id, idc in enumerate(client_idcs):
            for idx in idc:
                label_distribution[labels[idx]].append(c_id)

        plt.hist(label_distribution, stacked=True,
                    bins=np.arange(-0.5, n_clients + 1.5, 1),
                    label=classes, rwidth=0.5)
        plt.xticks(np.arange(n_clients), ["Client %d" %
                                            c_id for c_id in range(n_clients)])
        plt.xlabel("Client ID")
        plt.ylabel("Number of samples")
        plt.legend()
        plt.title("Display Label Distribution on Different Clients")
        plt.savefig(f"{data_path}/{FL_params.data_name}_noniid_plot.png")

        # save the segmented dataset
        torch.save(client_dataset, client_dataset_path)

        
    
    else: 
        client_dataset = torch.load(client_dataset_path)

    client_loaders = []
    for ii in range(FL_params.N_total_client):
        client_loaders.append(DataLoader(client_dataset[ii], FL_params.local_batch_size, shuffle=True, **kwargs))
    
        '''
        By now, we have separated the local data of the client user and stored it in client_loaders.
        Each corresponds to a user's private data
        '''
    
    return client_loaders, test_loader


def balance_split(num_clients, num_samples):
    """Assign same sample sample for each client.

    Args:
        num_clients (int): Number of clients for partition.
        num_samples (int): Total number of samples.

    Returns:
        numpy.ndarray: A numpy array consisting ``num_clients`` integer elements, each represents sample number of corresponding clients.

    """
    num_samples_per_client = int(num_samples / num_clients)
    client_sample_nums = (np.ones(num_clients) * num_samples_per_client).astype(
        int)
    return client_sample_nums


def client_inner_dirichlet_partition(labels, num_clients, num_classes, dir_alpha,
                                     client_sample_nums, verbose=True):
    """Non-iid Dirichlet partition.

    The method is from The method is from paper `Federated Learning Based on Dynamic Regularization <https://openreview.net/forum?id=B7v4QMR6Z9w>`_.
    This function can be used by given specific sample number for all clients ``client_sample_nums``.
    It's different from :func:`hetero_dir_partition`.

    Args:
        labels (list or numpy.ndarray): Sample labels.
        num_clients (int): Number of clients for partition.
        num_classes (int): Number of classes in samples.
        dir_alpha (float): Parameter alpha for Dirichlet distribution.
        client_sample_nums (numpy.ndarray): A numpy array consisting ``num_clients`` integer elements, each represents sample number of corresponding clients.
        verbose (bool, optional): Whether to print partition process. Default as ``True``.

    Returns:
        dict: ``{ client_id: indices}``.

    """
    if not isinstance(labels, np.ndarray):
        labels = np.array(labels)

    class_priors = np.random.dirichlet(alpha=[dir_alpha] * num_classes,
                                       size=num_clients)
    prior_cumsum = np.cumsum(class_priors, axis=1)
    idx_list = [np.where(labels == i)[0] for i in range(num_classes)]
    class_amount = [len(idx_list[i]) for i in range(num_classes)]

    client_indices = [np.zeros(client_sample_nums[cid]).astype(np.int64) for cid in
                      range(num_clients)]

    while np.sum(client_sample_nums) != 0:
        curr_cid = np.random.randint(num_clients)
        # If current node is full resample a client
        if verbose:
            print('Remaining Data: %d' % np.sum(client_sample_nums))
        if client_sample_nums[curr_cid] <= 0:
            continue
        client_sample_nums[curr_cid] -= 1
        curr_prior = prior_cumsum[curr_cid]
        while True:
            curr_class = np.argmax(np.random.uniform() <= curr_prior)
            # Redraw class label if no rest in current class samples
            if class_amount[curr_class] <= 0:
                continue
            class_amount[curr_class] -= 1
            client_indices[curr_cid][client_sample_nums[curr_cid]] = \
                idx_list[curr_class][class_amount[curr_class]]

            break

    client_dict = {cid: client_indices[cid] for cid in range(num_clients)}
    return client_dict


def merge_client_subsets(client_dataset, trainset, merge_indices_list):
    """
        merge the client dataset

        Args:
            client_dataset (list): original client dataset list
            trainset (Dataset): original dataset object
            merge_indices_list (list): the list of indices of the subsets to be merged (0-based)
        Returns:
            merged_subset (Subset): the merged subset
    """

    # check if the indices are valid
    for idx in merge_indices_list:
        if idx < 0 or idx >= len(client_dataset):
            raise ValueError(f"索引 {idx} 超出范围，client_dataset的长度为 {len(client_dataset)}")

    # get all indices of the subsets to be merged and merge them into a single list
    all_indices = []
    for idx in merge_indices_list:
        all_indices.extend(client_dataset[idx].indices) 
    

    # create a new subset using the merged indices
    merged_subset = torch.utils.data.Subset(trainset, all_indices)
    
    return merged_subset

def data_set_for_attack(FL_params):

    data_name = FL_params.data_name
    

    data_path = f"./{FL_params.model_result_name}/{data_name}"
    client_dataset_path = f'{data_path}/{data_name}_client_dataset.pth'

    client_dataset = torch.load(client_dataset_path)

    train_set = merge_client_subsets(client_dataset, client_dataset[0].dataset, FL_params.attack_clients_idx)

    
    return train_set


def data_set(data_name):
    # if not data_name in ['MNIST','CIFAR10','GTSRB','FASHION_MNIST']:
    #     raise TypeError('data_name should be a string, including mnist,GTSRB,cifar10. ')


    if(data_name == 'CIFAR10'):

        transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(), # converting images to tensor
        transforms.Normalize(mean = (0.5, 0.5, 0.5), std = (0.5, 0.5, 0.5)) 
        # if the image dataset is black and white image, there can be just one number. 
        ])
        
        transform_test = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean = (0.5, 0.5, 0.5), std = (0.5, 0.5, 0.5))
        ])


        trainset = datasets.CIFAR10(root='./data', train=True,
                                            download=False, transform=transform_train)


        testset = datasets.CIFAR10(root='./data', train=False,
                                                download=False, transform=transform_test)

    elif(data_name == 'PATHMNIST'):
        import medmnist
        from medmnist import INFO

        info = INFO['pathmnist']
        DataClass = getattr(medmnist, info['python_class'])

        # preprocessing
        transform_train = transforms.Compose([
            transforms.RandomRotation(15),                          
            transforms.RandomResizedCrop(28, scale=(0.8, 1.0)),       
            transforms.RandomHorizontalFlip(),                      
            transforms.ToTensor(),                                  
            transforms.Normalize(mean=[.5], std=[.5])
        ])

        transform_test = transforms.Compose([
            transforms.ToTensor(),                                  
            transforms.Normalize(mean=[.5], std=[.5])
        ])


        data = np.load('./data/pathmnist/pathmnist.npz')
        train_images = data['train_images']
        train_labels = data['train_labels'].reshape(-1)
        test_images  = data['test_images']
        test_labels  = data['test_labels'].reshape(-1)
        
        trainset = NPZDataset(train_images, torch.tensor(train_labels, dtype=torch.long), transform=transform_train)
        testset = NPZDataset(test_images, torch.tensor(test_labels, dtype=torch.long), transform=transform_test)


    elif(data_name == 'GTSRB'):
     
        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),             
            transforms.RandomHorizontalFlip(),                
            transforms.ColorJitter(brightness=0.5, contrast=0.2, saturation=0.2, hue=0.1),  
            transforms.RandomRotation(15),                   
            transforms.ToTensor(),                            
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]) 
        ])

        transform_test = transforms.Compose([
            transforms.ToTensor(),                            
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])  
        ])

        data = np.load('./data/gtsrb/gtsrb.npz')
        train_images = data['train_images']
        train_labels = data['train_labels']
        test_images  = data['test_images']
        test_labels  = data['test_labels']
        
        trainset = NPZDataset(train_images, torch.tensor(train_labels, dtype=torch.long), transform=transform_train)
        testset = NPZDataset(test_images, torch.tensor(test_labels, dtype=torch.long), transform=transform_test)

        
    return trainset, testset


def data_set_outter(data_name):

    if(data_name == 'CIFAR10'): #---tiny_imagenet_200
        transform_train = transforms.Compose([
        transforms.Resize(32),    
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(), # converting images to tensor
        transforms.Normalize(mean = (0.5, 0.5, 0.5), std = (0.5, 0.5, 0.5)) 
        # if the image dataset is black and white image, there can be just one number. 
        ])
        
        transform_test = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean = (0.5, 0.5, 0.5), std = (0.5, 0.5, 0.5))
        ])

        trainset = datasets.ImageFolder(root='./data/tiny-imagenet-200/train/', transform=transform_train)
        testset = datasets.ImageFolder(root='./data/tiny-imagenet-200/val/', transform=transform_test)

    elif(data_name == 'PATHMNIST'): #---dermamnist
        import medmnist
        from medmnist import INFO

        info = INFO['dermamnist']
        DataClass = getattr(medmnist, info['python_class'])

        # preprocessing
        transform_train = transforms.Compose([
            transforms.RandomRotation(15),                          
            transforms.RandomResizedCrop(28, scale=(0.8, 1.0)),       
            transforms.RandomHorizontalFlip(),                     
            transforms.ToTensor(),                                  
            transforms.Normalize(mean=[.5], std=[.5])
        ])

        transform_test = transforms.Compose([
            transforms.ToTensor(),                                  
            transforms.Normalize(mean=[.5], std=[.5])
        ])



        data = np.load('./data/dermamnist/dermamnist.npz')
        train_images = data['train_images']
        train_labels = data['train_labels'].reshape(-1)
        test_images  = data['test_images']
        test_labels  = data['test_labels'].reshape(-1)
        
        trainset = NPZDataset(train_images, torch.tensor(train_labels, dtype=torch.long), transform=transform_train)
        testset = NPZDataset(test_images, torch.tensor(test_labels, dtype=torch.long), transform=transform_test)

    
    elif(data_name == 'GTSRB'): #---TSRD


        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),            
            transforms.RandomHorizontalFlip(),                
            transforms.ColorJitter(brightness=0.5, contrast=0.2, saturation=0.2, hue=0.1), 
            transforms.RandomRotation(15),                    
            transforms.ToTensor(),                           
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]) 
        ])

        transform_test = transforms.Compose([
            transforms.ToTensor(),                            
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])  
        ])


        data = np.load('./data/ctsrb/ctsrb.npz')
        train_images = data['train_images']
        train_labels = data['train_labels']
        test_images  = data['test_images']
        test_labels  = data['test_labels']
        
        trainset = NPZDataset(train_images, torch.tensor(train_labels, dtype=torch.long), transform=transform_train)
        testset = NPZDataset(test_images, torch.tensor(test_labels, dtype=torch.long), transform=transform_test)

        
    
    return trainset, testset





from torch.utils.data import Dataset
from PIL import Image


class NPZDataset(Dataset):
    def __init__(self, images, labels, transform=None):
        """
        Args:
          images: numpy array, shape like (N, H, W) or (N, H, W, C)
          labels: numpy array, shape (N,)
          transform: transformation for PIL.Image
        """
        self.images = images
        self.labels = labels
        self.targets = labels.tolist()
        self.classes = np.unique(labels)
        self.transform = transform

    def __len__(self):
        return self.images.shape[0]

    def __getitem__(self, idx):
        # read image and label
        img = self.images[idx]
        label = self.labels[idx]
        # check if label is a numpy array
        if isinstance(label, np.ndarray):
            label = label.item()

        # check img type 
        if img.ndim == 2:
            img = Image.fromarray(img.astype(np.uint8), mode='L')
        elif img.ndim == 3:
            img = Image.fromarray(img.astype(np.uint8), mode='RGB')
        else:
            raise ValueError("Unsupported image shape: {}".format(img.shape))
            
        if self.transform:
            img = self.transform(img)
        else:
            img = torch.from_numpy(np.array(img)).float()
        return img, label

