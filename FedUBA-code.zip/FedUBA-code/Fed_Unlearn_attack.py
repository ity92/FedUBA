# -*- coding: utf-8 -*-

import torch
import copy
import numpy as np
import time

import math

from Fed_test import test, test_backdoor

from Fed_train import fedavg, global_train_once, FL_Train, median, trim_mean
import tqdm
import os

from Fed_data_change import dataloader_change_for_attack



#%%
def federated_learning_unlearning(init_global_model, client_loaders, test_loader, FL_params):
    
    all_start_time = time.time()

    '''step1. Train or import the initial federated learning model'''
    print(5*"#"+f" {FL_params.id}.1 Federated Learning Start "+5*"#")
    FL_Primitive_Model_old_GMs_save_path = f'{FL_params.FL_Model_dir}/FL_{FL_params.aggregation_method}_PGMs_Gp{FL_params.global_epoch}_Lp{FL_params.local_epoch}_bs{FL_params.local_batch_size}.pth'
    FL_Primitive_Model_old_CMs_save_path = f'{FL_params.FL_Model_dir}/FL_{FL_params.aggregation_method}_PCMs_Gp{FL_params.global_epoch}_Lp{FL_params.local_epoch}_bs{FL_params.local_batch_size}.pth'
    std_time = time.time()
    if os.path.exists(FL_Primitive_Model_old_GMs_save_path) and os.path.exists(FL_Primitive_Model_old_CMs_save_path) and not FL_params.if_train:
        # Extract parameter
        old_GMs_dicts = torch.load(FL_Primitive_Model_old_GMs_save_path)
        old_CMs_dicts = torch.load(FL_Primitive_Model_old_CMs_save_path)
        # Initialization model
        old_GMs = [copy.deepcopy(init_global_model) for _ in range(len(old_GMs_dicts))]
        old_CMs = [copy.deepcopy(init_global_model) for _ in range(len(old_CMs_dicts))]
        # Load parameter
        for GMs_idx in range(len(old_GMs_dicts)):
            old_GMs[GMs_idx].load_state_dict(old_GMs_dicts[GMs_idx])
        for CMs_idx in range(len(old_CMs_dicts)):
            old_CMs[CMs_idx].load_state_dict(old_CMs_dicts[CMs_idx])

        old_epoch_result_in_test = np.load(FL_Primitive_Model_old_GMs_save_path.replace(".pth","_Rtest.npy"),allow_pickle=True).tolist()


        print(5*"#"+f" {FL_params.id}.1 Find FL_Primitive_Model old_GMS & old_CMs, Load Successfuly! "+5*"#")
        
    else:
        # Training FL model
        old_GMs, old_CMs,  old_epoch_result_in_test = FL_Train(init_global_model, client_loaders, test_loader, FL_params)
        # Extract parameter
        old_GMs_dicts = [model_temp.state_dict() for model_temp in old_GMs]
        old_CMs_dicts = [model_temp.state_dict() for model_temp in old_CMs]
        # Save parameter
        np.save(FL_Primitive_Model_old_GMs_save_path.replace(".pth","_Rtest.npy"),np.array(old_epoch_result_in_test,dtype=object))
        torch.save(old_GMs_dicts, FL_Primitive_Model_old_GMs_save_path)
        torch.save(old_CMs_dicts, FL_Primitive_Model_old_CMs_save_path)
        
        print(5*"#"+f" {FL_params.id}.1 Not Find FL_Primitive_Model old_GMS & old_CMs, Train and Save Successfuly! "+5*"#")
    
    end_time = time.time()
    time_learn = ( end_time - std_time )


    '''step2. Train an unlearn model under attack'''
    unlearn_attack_GMs_save_path = f'{FL_params.FL_Attacked_Model_dir}/Trigger_{FL_params.trigger_id}_UAGMs_{FL_params.attack_scheme}_RateWClass_TTC{FL_params.triggerToClass}_itv{FL_params.unlearn_interval}_Fratio{str(int(FL_params.forget_local_epoch_ratio*100))}.pth'
    unlearn_attack_CMs_save_path = f'{FL_params.FL_Attacked_Model_dir}/Trigger_{FL_params.trigger_id}_UACMs_{FL_params.attack_scheme}_RateWClass_TTC{FL_params.triggerToClass}_itv{FL_params.unlearn_interval}_Fratio{str(int(FL_params.forget_local_epoch_ratio*100))}.pth'
    print(5*"#"+f" {FL_params.id}.2 Federated Unlearning Attack Start "+5*"#")
    std_time = time.time()
    if os.path.exists(unlearn_attack_GMs_save_path) and not FL_params.if_unlearning_attack:
        
        # Extract parameter
        unlearn_attack_GMs_dicts = torch.load(unlearn_attack_GMs_save_path)
        unlearn_attack_CMs_dicts = torch.load(unlearn_attack_CMs_save_path)
        # Initialization model
        unlearn_attack_GMs = [copy.deepcopy(init_global_model) for _ in range(len(unlearn_attack_GMs_dicts))]
        unlearn_attack_CMs = [copy.deepcopy(init_global_model) for _ in range(len(unlearn_attack_CMs_dicts))]
        # Load parameter
        for GMs_idx in range(len(unlearn_attack_GMs_dicts)):
            unlearn_attack_GMs[GMs_idx].load_state_dict(unlearn_attack_GMs_dicts[GMs_idx])
        for CMs_idx in range(len(unlearn_attack_CMs_dicts)):
            unlearn_attack_CMs[CMs_idx].load_state_dict(unlearn_attack_CMs_dicts[CMs_idx])

        attack_epoch_result_in_test = np.load(unlearn_attack_GMs_save_path.replace(".pth","_Rtest.npy"),allow_pickle=True).tolist()
        all_change_result_dict_list = np.load(unlearn_attack_GMs_save_path.replace(".pth","_Rchange.npy"),allow_pickle=True).tolist()

        print(5*"#"+f" {FL_params.id}.2 Find unlearn_attack_GMs, Load Successfuly! "+5*"#")
        
    else:
        # Training FL unlearning attack model
        unlearn_attack_GMs, unlearn_attack_CMs,  attack_epoch_result_in_test, all_change_result_dict_list = unlearning_attack(old_GMs, old_CMs, client_loaders, test_loader, FL_params)
        # Extract parameter
        unlearn_attack_GMs_dicts = [model_temp.state_dict() for model_temp in unlearn_attack_GMs]
        unlearn_attack_CMs_dicts = [model_temp.state_dict() for model_temp in unlearn_attack_CMs]
        # Save parameter
        np.save(unlearn_attack_GMs_save_path.replace(".pth","_Rtest.npy"),np.array(attack_epoch_result_in_test,dtype=object))
        np.save(unlearn_attack_GMs_save_path.replace(".pth","_Rchange.npy"),np.array(all_change_result_dict_list,dtype=object))
        torch.save(unlearn_attack_GMs_dicts, unlearn_attack_GMs_save_path)
        torch.save(unlearn_attack_CMs_dicts, unlearn_attack_CMs_save_path)

        print(5*"#"+f" {FL_params.id}.2 Not Find unlearn_attack_GMs, Train and Save Successfuly! "+5*"#")
    end_time = time.time()
    time_unlearn_attack = ( end_time - std_time )
    print(5*"#"+" unlearn_attack End "+5*"#")

    

    '''step3. Prepare the output'''
    # record for training parameters
    train_str = f"{FL_params.data_name}_clients{FL_params.chosen_clients_str}_{FL_params.aggregation_method}_Gepoch{FL_params.global_epoch}_Lepoch{FL_params.local_epoch}_batchsize{FL_params.local_batch_size}"
    # record for unlearning attack parameters
    unlearn_attack_str = f"Trigger_{FL_params.trigger_id}_Attaker_client{FL_params.attack_clients_str}_{FL_params.attack_scheme}_intervalc{FL_params.unlearn_interval}_Fratio{str(int(FL_params.forget_local_epoch_ratio*100))}"#遗忘攻击参数
    # record for the results
    result = ( (train_str, old_epoch_result_in_test[-1][-1], test_backdoor(old_GMs[-1],test_loader.dataset,FL_params)),
              (unlearn_attack_str, attack_epoch_result_in_test[-1][-1], test_backdoor(unlearn_attack_GMs[-1],test_loader.dataset,FL_params)))
    # print the total time spent
    print(5*"#"+f" Idx.{FL_params.id} cost time: "+f"{time.time()-all_start_time}"+5*"#")
    # print the change of the model
    print("Before unlearn attack, ","Clear prediction in test-----",result[0][1],"Trigger prediction in test-----",result[0][2])
    print("After unlearn attack, ","Clear prediction in test-----",result[1][1],"Trigger prediction in test-----",result[1][2])

    return old_GMs, old_CMs, unlearn_attack_GMs, unlearn_attack_CMs_dicts, result, all_change_result_dict_list
    

#%%
def unlearning_attack(old_GMs, old_CMs, client_data_loaders, test_loader, FL_params):
    """
    
    Parameters
    ----------
    old_global_models : list of DNN models
        In standard federated learning, all the global models from each round of training are saved.
    old_client_models : list of local client models
        In standard federated learning, the server collects all user models after each round of training.
    client_data_loaders : list of torch.utils.data.DataLoader
        This can be interpreted as each client user's own data, and each Dataloader corresponds to each user's data
    test_loader : torch.utils.data.DataLoader
        The loader for the test set used for testing
    FL_params : Argment()
        The parameter class used to set training parameters

    Returns
    -------
    forget_global_model : One DNN model that has the same structure but different parameters with global_moedel
        DESCRIPTION.

    """

    # Check whether the parameters are correct
    if(not(max(FL_params.attack_clients_idx) in range(FL_params.N_client) and min(FL_params.attack_clients_idx)>=0)):
        raise ValueError('FL_params.attack_clients_idx is note assined correctly, attack_clients_idx should in {}'.format(range(FL_params.N_client)))
    if(FL_params.unlearn_interval == 0 or FL_params.unlearn_interval >FL_params.global_epoch):
        raise ValueError('FL_params.unlearn_interval should not be 0, or larger than the number of FL_params.global_epoch')
    
    # Initialization model
    old_global_models = copy.deepcopy(old_GMs)
    old_client_models = copy.deepcopy(old_CMs)
    
    for ii in range(FL_params.global_epoch):
        temp = old_client_models[ii*FL_params.N_client : ii*FL_params.N_client+FL_params.N_client]
        old_client_models.append(temp)
    old_client_models = old_client_models[-FL_params.global_epoch:]
    
    GM_intv = np.arange(0,FL_params.global_epoch+1, FL_params.unlearn_interval, dtype=np.int16())
    CM_intv = GM_intv[:-1]
    
    selected_GMs = [old_global_models[ii] for ii in GM_intv]
    selected_CMs = [old_client_models[jj] for jj in CM_intv]
    
    
    # Initializes the global model with epoch 0
    epoch = 0
    unlearn_global_models = list()
    unlearn_client_models = list()
    unlearn_global_models.append(copy.deepcopy(selected_GMs[0]))

    epoch_result_in_test = list()
    epoch_result_in_test.append( [0,test(unlearn_global_models[-1], test_loader)] )


    # Prepare the data set to unlearning attack
    prepare_std_time = time.time()
    client_data_loaders_prepare = list()
    attack_clients_data_loader = list()
    all_change_result_dict_list = list()
    attack_scheme = FL_params.attack_scheme
    print("attack_scheme:",attack_scheme)

    for ii_idx in range(FL_params.N_client):
        client_data_loader_temp = copy.deepcopy(client_data_loaders[ii_idx])
        client_data_loaders_prepare.append(client_data_loader_temp) 
        
        if ii_idx in FL_params.attack_clients_idx:
            attack_clients_data_loader.append(client_data_loader_temp)

    # Modify the data of the attacked client
    client_data_loader_temp,all_change_result_dict_list = dataloader_change_for_attack(attack_clients_data_loader,
                                                            attack_scheme, FL_params, old_GMs[-1])

    for i_idx,attack_client_idx in enumerate(FL_params.attack_clients_idx): 
        client_data_loaders_prepare[attack_client_idx] = copy.deepcopy(client_data_loader_temp[i_idx])

    print("attack dataloader preparation cost time:",time.time()-prepare_std_time)


    # Prepare unlearning epoch
    CONST_local_epoch = copy.deepcopy(FL_params.local_epoch)
    FL_params.local_epoch = np.ceil(FL_params.local_epoch*FL_params.forget_local_epoch_ratio)
    FL_params.local_epoch = np.int16(FL_params.local_epoch)

    CONST_global_epoch = copy.deepcopy(FL_params.global_epoch)
    FL_params.global_epoch = CM_intv.shape[0]
    

    # Prepare the learning rate
    if FL_params.cosine_annealing_lr:
        # store the initial learning rate
        start_lr = FL_params.local_lr
        # cosine annealing learning rate
        def cosine_annealing_lr(epoch, T_max, initial_lr, min_lr):
            return min_lr + (initial_lr - min_lr) * (1 + math.cos(math.pi * epoch / T_max)) / 2


    # Start training the unlearning model
    print('FL_Unlearning_Attack parameters: Clients = {} ,Global epoch = {}, Local Calibration Training epoch = {}'.format(FL_params.chosen_clients_str[1:],FL_params.global_epoch,FL_params.local_epoch))
    desc_str = f"{FL_params.aggregation_method},Attackers{FL_params.attack_clients_str},Trigger_{FL_params.trigger_id}|FL Unlearning Attack:"
    global_epoch_bar = tqdm.trange(FL_params.global_epoch,colour="red",desc=desc_str)
    for epoch in global_epoch_bar:

        global_model = unlearn_global_models[epoch]

        # Prepare the learning rate
        if FL_params.cosine_annealing_lr:
            # cosine annealing learning rate
            FL_params.local_lr = cosine_annealing_lr(epoch, FL_params.global_epoch, start_lr, 0)

        new_client_models  = global_train_once(global_model, client_data_loaders_prepare, test_loader, FL_params)

        if epoch == 0:
            for ii_idx in range(FL_params.N_client):
                if ii_idx not in FL_params.attack_clients_idx:
                    new_client_models[ii_idx] = copy.deepcopy(selected_CMs[epoch][ii_idx])

        new_GM, new_CM = unlearning_step_once(selected_CMs[epoch], new_client_models, selected_GMs[epoch], global_model, FL_params)
    

        unlearn_global_models.append(new_GM)
        unlearn_client_models += new_CM

        if FL_params.train_with_test:
            global_epoch_bar.set_postfix(Loss='{:.2e}'.format(epoch_result_in_test[-1][1][0]),# the loss of test set
                                     Acc='{:.1f}'.format(epoch_result_in_test[-1][1][1]))# the accuracy of test set

            
            epoch_result_in_test.append( [epoch+1,test(unlearn_global_models[-1], test_loader)] )
            


        
    FL_params.local_epoch = CONST_local_epoch
    FL_params.global_epoch = CONST_global_epoch

    
    # Prepare the learning rate
    if FL_params.cosine_annealing_lr:
        # recover the initial learning rate
        FL_params.local_lr = start_lr

    return unlearn_global_models, unlearn_client_models, epoch_result_in_test, all_change_result_dict_list



#%%
def unlearning_step_once(old_client_models, new_client_models, global_model_before_forget, global_model_after_forget, FL_params):
    """
    
    Parameters
    ----------
    old_client_models : list of DNN models
        When there is no choice to forget (if_forget=False), use the normal continuous learning training to get each user's local model.The old_client_models do not contain models of users that are forgotten.
        Models that require forgotten users are not discarded in the Forget function
    ref_client_models : list of DNN models
        When choosing to forget (if_forget=True), train with the same Settings as before, except that the local epoch needs to be reduced, other parameters are set in the same way.
        Using the above training Settings, the new global model is taken as the starting point and the reference model is trained.The function of the reference model is to identify the direction of model parameter iteration starting from the new global model
        
    global_model_before_forget : The old global model
        DESCRIPTION.
    global_model_after_forget : The New global model
        DESCRIPTION.

    Returns
    -------
    return_global_model : After one iteration, the new global model under the forgetting setting

    """
    old_param_update = dict()#Model Params： oldCM - oldGM_t
    new_param_update = dict()#Model Params： newCM - newGM_t
    
    new_global_model_state = global_model_after_forget.state_dict()#newGM_t
    
    return_model_state = dict()#newGM_t + ||oldCM - oldGM_t||*(newCM - newGM_t)/||newCM - newGM_t||
    

    assert len(old_client_models) == len(new_client_models)
    

    clients_dicts_list = list()
    for client_idx in range(len(old_client_models)):
        
        return_model_state = dict()#newGM_t + ||oldCM - oldGM_t||*(newCM - newGM_t)/||newCM - newGM_t||
        
        for layer in global_model_before_forget.state_dict().keys():
            old_param_update[layer] = 0*global_model_before_forget.state_dict()[layer]
            new_param_update[layer] = 0*global_model_before_forget.state_dict()[layer]
            
            return_model_state[layer] = 0*global_model_before_forget.state_dict()[layer]
            
            # Copy old and new models
            old_param_update[layer] += old_client_models[client_idx].state_dict()[layer]
            new_param_update[layer] += new_client_models[client_idx].state_dict()[layer]
            
            # Calculate new and old update values
            old_param_update[layer] = old_param_update[layer] - global_model_before_forget.state_dict()[layer]#Parameters: oldCM - oldGM_t
            new_param_update[layer] = new_param_update[layer] - global_model_after_forget.state_dict()[layer]#Parameters: newCM - newGM_t

            # Calculate the final update model
            step_length = torch.norm(old_param_update[layer].float())#||oldCM - oldGM_t||
            step_direction = torch.norm(new_param_update[layer].float())#||newCM - newGM_t||
            step_direction = new_param_update[layer] if step_direction==0 else new_param_update[layer]/torch.norm(new_param_update[layer].float())#(newCM - newGM_t)/||newCM - newGM_t||
            
            return_model_state[layer] = new_global_model_state[layer] + step_length*step_direction
        
        clients_dicts_list.append( copy.deepcopy(return_model_state) )
    
    assert len(clients_dicts_list) == len(new_client_models)
    
    client_model = list()
    for client_dicts in clients_dicts_list:
        model_temp = copy.deepcopy(global_model_after_forget)
        model_temp.load_state_dict(client_dicts)
        client_model.append(model_temp)

    all_methods = ["fedavg", "median", "trim-mean"]
    if FL_params.aggregation_method == "fedavg":
        return fedavg(client_model), client_model
    elif FL_params.aggregation_method == "median":
        return median(client_model), client_model
    elif FL_params.aggregation_method == "trim-mean":
        return trim_mean(client_model, FL_params.percentage), client_model
    else:
        raise ValueError(f'No such method in aggregation, please check it! Only {all_methods}')
    
    