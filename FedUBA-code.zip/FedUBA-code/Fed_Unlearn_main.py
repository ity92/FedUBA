
import torch
import numpy as np
import os


from Fed_model_initiation import model_init
from Fed_data_preprocess import data_init, data_init_non_iid

from Fed_Unlearn_attack import federated_learning_unlearning


from trigger_generate_function import trigger_generate


"""Step 0. Initialize Federated Unlearning parameters"""
class Arguments():
    def __init__(self, args):

        #Federated Learning Settings
        self.data_name = 'CIFAR10'
        self.data_split = 'iid'
        self.data_classes = 10

        self.N_total_client = 20
        self.N_client = 10

        self.aggregation_method = 'fedavg' 
        self.percentage = 0.1   

        self.global_epoch = 20 
        self.local_epoch = 10

        self.selected_clients = [2,3,5,7,9,12,13,16,18,19]       
        

        #Model Training Settings
        self.local_batch_size = 128
        self.local_lr = 0.01 
        self.cosine_annealing_lr = True 
        self.test_batch_size = 128
        

        
        #Federated Unlearning Settings
        self.unlearn_interval= 1
            #Used to control how many rounds the model parameters are saved.1 represents the parameter saved once per round  N_itv in our paper.
            #If this parameter is set to False, only the global model after the final training is completed is output        
        self.forget_local_epoch_ratio = 0.5
            #When a user is selected to be forgotten, other users need to train several rounds of on-line training in their respective data sets to obtain the general direction of model convergence in order to provide the general direction of model convergence.
            #forget_local_epoch_ratio*local_epoch Is the number of rounds of local training when we need to get the convergence direction of each local model



        # Attack Settings
        self.attack_clients_idx = [2,3]
        self.trigger_id = 1
        self.trigger = None
        self.attack_scheme = None
        self.triggerToClass = 2
        self.multi_test_list = [1.5]
        self.trigger_limit = 16/255

        # others
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.seed = 42
        self.model_result_name = "./result"
        self.train_with_test = True
        self.if_train = False
        self.if_unlearning_attack = False    


def Save_paths_init(FL_params):
    my_index = FL_params.id
    '''step0. Set up the total save folder for the training model, check it, and create it if it does not exist'''
    print(5*"#"+f" {my_index}.0-1 Initialize Federated models save path "+5*"#")
    FL_params.chosen_clients_str = ""
    for _ in FL_params.selected_clients:
        FL_params.chosen_clients_str += "_" + str(_)
    FL_Model_dir = f"./{FL_params.model_result_name}/{FL_params.data_name}_clients{FL_params.chosen_clients_str}"
    FL_params.FL_Model_dir = FL_Model_dir
    
    if not os.path.exists(FL_Model_dir):
        os.makedirs(FL_Model_dir)
        print(5*"#"+f" {my_index}.0 Not found resutl dir, already made it: ",FL_Model_dir,5*"#")
    else:
        print(5*"#"+f" {my_index}.0 resutl dir is already existed: ",FL_Model_dir,5*"#")


    FL_params.attack_clients_str = ""
    for _ in FL_params.attack_clients_idx:
        FL_params.attack_clients_str += "_" + str(FL_params.selected_clients[_])

    
    '''step1. Set the total save folder of the unlearning attack model, and check it, and create it if it does not exist'''
    print(5*"#"+f" {FL_params.id}.0-2 Initialize Federated Unlearning Attack models save path "+5*"#")
    FL_Attacked_Model_dir = FL_Model_dir + f"/FL_{FL_params.aggregation_method}_Attaker_client{FL_params.attack_clients_str}"
    if not os.path.exists(FL_Attacked_Model_dir):
        os.makedirs(FL_Attacked_Model_dir)
        os.makedirs(FL_Attacked_Model_dir+"/result")
        print(5*"#"+f" {FL_params.id}.2 Not found resutl dir, already made it: ",FL_Attacked_Model_dir,5*"#")
    else:
        print(5*"#"+f" {FL_params.id}.2 resutl dir is already existed: ",FL_Attacked_Model_dir,5*"#")
    FL_params.FL_Attacked_Model_dir = FL_Attacked_Model_dir
    FL_params.FL_Attacked_Model_result_dir = FL_Attacked_Model_dir+"/result"

    return FL_params




def Federated_Unlearning():

    """Step 1.Set the parameters for Federated Unlearning"""
    FL_params = Arguments(" ")
    print(FL_params)
    
    torch.manual_seed(FL_params.seed)
    #kwargs for data loader 
    print(60*'=')
    print("Step1. Federated Learning Settings \n We use dataset: "+FL_params.data_name+(" for our Federated Unlearning experiment.\n"))


    """Step 2. construct the necessary user private data set required for federated learning, as well as a common test set"""
    print(60*'=')
    print("Step2. Client data loaded, testing data loaded!!!\n       Initial Model loaded!!!")  
    init_global_model = model_init(FL_params.data_name)

    if FL_params.data_split == 'iid':
        client_all_loaders, test_loader = data_init(FL_params)
    elif FL_params.data_split == 'noniid':
        client_all_loaders, test_loader = data_init_non_iid(FL_params)
    else:
        raise ValueError(f'No such data_split, please check it! Only iid or noniid')

    client_loaders = list()
    all_train_num = 0
    for idx in FL_params.selected_clients:
        client_loaders.append(client_all_loaders[idx])
        all_train_num += len(client_all_loaders[idx].dataset)
    


    """Step 3. Select a client's data to forget，1.Federated Learning, 2.Unlearning(FedEraser), and 3.(Accumulating)Unlearing without calibration"""
    print(60*'=')
    print("Step3. Fedearated Learning and Unlearning Training...")
    
    # trigger noise generation
    trigger_generate(FL_params)
    # trigger noise loading
    FL_params.noise_npy = np.load(f'./trigger_noise/trigger_{FL_params.data_name}.npy')
    FL_params.trigger = torch.from_numpy(FL_params.noise_npy).cuda()

    # attack scheme
    attack_scheme = f"Trigger_feature_{(int)(all_train_num*0.005)}"

    FL_params.attack_scheme = attack_scheme

    # test id set
    FL_params.id = 0

    # print the parameters
    print(f"id:{FL_params.id}--", 
            f"Aggregation_method: {FL_params.aggregation_method}, Attack_scheme: {FL_params.attack_scheme}, Trigger_id: {FL_params.trigger_id}, TriggerToClass: {FL_params.triggerToClass}")
    
    # initialize the paths
    FL_params = Save_paths_init(FL_params)

    # train the model and unlearn attack
    old_GMs, old_CMs, unlearn_attack_GMs, unlearn_attack_CMs_dicts, result, all_change_result_dict_list  = federated_learning_unlearning(init_global_model, 
                                                        client_loaders, 
                                                        test_loader, 
                                                        FL_params)
    

    # save the results
    np.save(f"./{FL_params.FL_Attacked_Model_result_dir}/{FL_params.data_name}_FL_train_result.npy",np.array(result,dtype=object))
    

    print("All done!")

if __name__=='__main__':
    Federated_Unlearning()














































