# -*- coding: utf-8 -*-


def model_init(data_name):
    if(data_name == 'PATHMNIST'):
        from models.mobilenetv2 import MobileNetV2
        model = MobileNetV2(9)
    elif(data_name == 'PATHMNIST_outter'):
        from models.mobilenetv2 import MobileNetV2
        model = MobileNetV2(8)
    elif(data_name == 'CIFAR10'):
        from models.resnet import ResNet18
        model = ResNet18()  
    elif(data_name == 'CIFAR10_outter'):
        from models.resnet import ResNet18_201
        model = ResNet18_201()
    elif(data_name == 'GTSRB'):
        from models.vgg import VGG
        model = VGG('VGG11', 43)
    elif(data_name == 'GTSRB_outter'):
        from models.vgg import VGG
        model = VGG('VGG11', 59)
    else:
        raise ValueError('data_name is not valid, no such model')
    return model


    