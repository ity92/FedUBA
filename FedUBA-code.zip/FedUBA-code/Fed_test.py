import torch
import torch.nn as nn
import numpy as np

from sklearn.metrics import accuracy_score

from torch.utils.data import Subset

from utils import get_labels, poison_image_label


"""
Function:
Test the performance of the model on the test set
"""

def test(model, test_loader, print_indicate=False):
    model.eval()
    device = (next(model.parameters())).device

    criterion = nn.CrossEntropyLoss()

    loss_list = []
    correct_clean, total_clean = 0, 0
    for i, (images, labels) in enumerate(test_loader):
        images, labels = images.to(device), labels.to(device)
        with torch.no_grad():
            logits = model(images)
            out_loss = criterion(logits,labels)
            _, predicted = torch.max(logits.data, 1)
            total_clean += labels.size(0)
            correct_clean += (predicted == labels).sum().item()
            loss_list.append(out_loss.item())

    acc_clean = correct_clean / total_clean * 100
    out_loss = sum(loss_list) / len(loss_list)

    if print_indicate:
        print('Test set: Average loss: {:.8f}'.format(out_loss))         
        print('Test set: Average acc:  {:.4f}'.format(acc_clean))    
    return (out_loss, acc_clean)

def test_target(model, test_loader, target_idx):
    model.eval()
    model_device = (next(model.parameters())).device

    all_data = []
    all_label = []
    with torch.no_grad():
        if type(target_idx) is not list:
            all_data.append(test_loader.dataset[target_idx][0])
            all_label.append(test_loader.dataset[target_idx][1])
        else:
            for idx in target_idx:
                all_data.append(test_loader.dataset[idx][0])
                all_label.append(test_loader.dataset[idx][1])
    
    all_data = torch.stack(all_data, dim=0).to(model_device)
    all_label = torch.tensor(all_label).to(model_device)
    

    output = model(all_data)
    criteria = nn.CrossEntropyLoss()
    test_loss = criteria(output, all_label) # sum up batch loss
    
    pred = torch.argmax(output,axis=1)
    test_acc = accuracy_score(pred.cpu(),all_label.cpu())*100
    test_loss /= len(test_loader.dataset)
 
    return (test_loss.item(), test_acc, output.cpu().tolist())

def test_backdoor(model,ori_test,FL_params):
    # base setup
    model.to(FL_params.device)
    device = FL_params.device
    criterion = nn.CrossEntropyLoss()
    test_batch_size = FL_params.test_batch_size
    multi_test_list = FL_params.multi_test_list
    
    # prepare the test data
    test_label = [get_labels(ori_test)[x] for x in range(len(get_labels(ori_test)))]
    # test for the non-target class
    asr_loaders = []
    test_non_target = list(np.where(np.array(test_label)!=FL_params.triggerToClass)[0])
    for multi_test in multi_test_list:
        test_non_target_change_image_label = poison_image_label(ori_test,test_non_target,FL_params.trigger.cpu()*multi_test,FL_params.triggerToClass,None)
        asr_loaders.append(torch.utils.data.DataLoader(test_non_target_change_image_label, batch_size=test_batch_size, shuffle=True))
    # load the clean test data
    clean_test_loader = torch.utils.data.DataLoader(ori_test, batch_size=test_batch_size, shuffle=False)
    # test for the target class
    test_target = list(np.where(np.array(test_label)==FL_params.triggerToClass)[0])
    target_test_set = Subset(ori_test,test_target)
    target_test_loader = torch.utils.data.DataLoader(target_test_set, batch_size=test_batch_size, shuffle=False)

    # Testing attack effect
    asr_results = []
    model.eval()
    for asr_loader in asr_loaders:
        correct, total = 0, 0
        for i, (images, labels) in enumerate(asr_loader):
            images, labels = images.to(device), labels.to(device)
            with torch.no_grad():
                logits = model(images)
                out_loss = criterion(logits,labels)
                _, predicted = torch.max(logits.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
        acc = correct / total * 100
        asr_results.append(acc)


    correct_clean, total_clean = 0, 0
    for i, (images, labels) in enumerate(clean_test_loader):
        images, labels = images.to(device), labels.to(device)
        with torch.no_grad():
            logits = model(images)
            out_loss = criterion(logits,labels)
            _, predicted = torch.max(logits.data, 1)
            total_clean += labels.size(0)
            correct_clean += (predicted == labels).sum().item()

    acc_clean = correct_clean / total_clean * 100

    
    correct_tar, total_tar = 0, 0
    for i, (images, labels) in enumerate(target_test_loader):
        images, labels = images.to(device), labels.to(device)
        with torch.no_grad():
            logits = model(images)
            out_loss = criterion(logits,labels)
            _, predicted = torch.max(logits.data, 1)
            total_tar += labels.size(0)
            correct_tar += (predicted == labels).sum().item()
    acc_tar = correct_tar / total_tar * 100

    return [asr_results,acc_clean,acc_tar]

