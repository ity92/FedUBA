
## About The Project----FedUBA

The main function is contained in Fed_Unlearn_main.py. 


## Getting Started
### Prerequisites
**Gradeint-Leaks** requires the following packages: 
- Python 3.8.3
- Pytorch 1.6
- Sklearn 0.23.1
- Numpy 1.18
- Scipy 1.5


### File Structure 
```
FedUBA under FedEraser
├── checkpoint
├── data
├── model
├── result
├── trigger_noise
├── Fed_data_change.py
├── Fed_data_preprocess.py
├── Fed_model_initiation.py
├── Fed_test.py
├── Fed_train.py
├── Fed_Unlearn_attack.py
├── Fed_Unlearn_main.py
├── influence_function.py
├── trigger_generate_function.py
└── utils.py
```
There are several parts of the code:
- checkpoint folder: This folder is used to store the model parameters generated in the middle.
- data folder: This folder contains the training and testing data for the target model.
- model folder: This folder stores the model structure used in this project.
- result folder: This folder is used to save the experimental results.
- trigger_noise folder: This folder is used to store the generated backdoor trigger (noise).
- Fed_data_change.py: This file contains the code for modifying the characteristics of malicious clients.
- Fed_data_preprocess.py: This file contains the preprocessing of the raw data in data folder.
- Fed_model_initiation.py: This file contains the relevant code for model initialization.
- Fed_test.py: This file contains the test-related code.
- Fed_train.py: This file contains the relevant code for model training.
- Fed_Unlearn_attack.py: This file contains the main code for training and forgetting attacks.
- Fed_Unlearn_main.py: This file is the main code of this project.
- influence_function.py: This file contains the code related to calculating the influence function.
- trigger_generate_function.py: This file contains the code related to the generation of backdoor triggers.

## Parameter Setting of FedEraser
The attack settings of Federated Unlearning attack are determined in **Fed_Unlearn_main.py**. 
- ***Federated Learning Model Training Settings***
-- FL_params.data_name: the dataset name
-- FL_params.data_split: the data set partitioning method
-- FL_params.N_total_client: the number of federated clients 
-- FL_params.N_client: the number of selected federated clients 
-- FL_params.aggregation: aggregation method of federated learning
-- FL_params.percentage: the remove percentage of each side in trim-mean aggregation method
-- FL_params.global_epoch: the number of global training  epoch in federated learning 
-- FL_params.local_epoch: the number of client local training   epoch in federated learning 
-- FL_params.selected_clients: the list of selected clients for federated learning 


- ***Model Training Settings***
-- FL_params.local_batch_size: the local batch size of the client's local training 
-- FL_params.local_lr: the local learning rate of the client's local training 
-- FL_params.test_batch_size: the testing  batch size of the client's local training 



- ***Federated Unlearning Settings***
-- FL_params.unlearn_interval: Used to control how many rounds the model parameters are saved. $1$ represents the parameter saved once per round. (corresponding to N_itv in our paper)
-- FL_params.forget_local_epoch_ratio: When a user is selected to be forgotten, other users need to train several rounds of on-line training in their respective data sets to obtain the general direction of model convergence in order to provide the general direction of model convergence. $forget_local_epoch_ratio \times local_epoch is$ the number of rounds of local training when we need to get the convergence direction of each local model              



- ***Attack Settings***
-- FL_params.attack_clients_idx: the clients that made the forget request to attack
-- FL_params.trigger_id: The indicator id of the backdoor trigger
-- FL_params.trigger: Backdoor trigger
-- FL_params.attack_scheme: the attack scheme
-- FL_params.triggerToClass: The target class for backdoor attacks
-- FL_params.multi_test_list: The overlay multiple of the backdoor trigger during a backdoor attack
-- FL_params.trigger_limit: The upper limit of the backdoor trigger


- ***others***
-- FL_params.seed: random seed 
-- FL_params.device: the designation of the operating device
-- FL_params.model_result_name: the root path used to store training results
-- FL_params.train_with_test: controlling whether testings are performed at the end of each global round of training
-- FL_params.if_train: used to determine whether to import the model or retrain the complete federated learning model during the training phase. If true, it will be retrained every time. The default is false, and it will not be retrained when the model is found.
-- FL_params.if_unlearning_attack: used to determine whether to import the model or retrain the federated unlearning attack model during the training phase. If true, it will be retrained every time. The default is false, and it will not be retrained when the model is found.


## Execute FedUBA
*** Run Fed_Unlearn_main.py.  ***




