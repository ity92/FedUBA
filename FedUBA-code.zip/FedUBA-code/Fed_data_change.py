
import torch
from torch.utils.data import DataLoader, Dataset
import copy
import numpy as np
from torchvision import transforms
from influence_function import influence_sort_function

from utils import poison_image

def dataloader_change_for_attack(client_dataloader_original,attack_scheme,FL_params,model):
    
    all_attack_schemes = ["Influence", "Random"]
    
    attack_scheme_split = attack_scheme.split("_")
    # The type is str, which is divided into four blocks: "Basic method _ Modification method _ Modification number _ Other parameters"

    if attack_scheme_split[0]=="Trigger":
        return trigger_data_change(client_dataloader_original,attack_scheme_split[1],attack_scheme_split[2:],
                                     FL_params,model)
    
    else:
        raise ValueError(f'No such attack_scheme, please check it! Only {all_attack_schemes}')
    
    

def trigger_data_change(all_client_dataloader_original,method,more_paraments,FL_params,model):


    number = int(more_paraments[0])
    result_dict = {}

    all_methods = ["delete", "feature"]
    kwargs = {'num_workers': 0, 'pin_memory': True}

    # calculate the influence function sort
    all_influence_sorts = []
    for i_idx,client_idx in enumerate(FL_params.attack_clients_idx):

        x_test = FL_params.trigger
        y_test = torch.tensor([FL_params.triggerToClass]).cuda()
        dataloader = DataLoader(all_client_dataloader_original[i_idx].dataset, batch_size=1, shuffle=True)
        influence_sort = influence_sort_function(x_test, y_test, dataloader, model, FL_params)
        all_influence_sorts.append(influence_sort)


    if method == "feature":
        print(f'change the feature')
        # the maximum number of samples that can be modified by a single client
        single_client_max_num = int(np.ceil(number/len(all_influence_sorts)))

        all_sliced_influence_idx_lists = list()
        for ii_idx,influence_sort in enumerate(all_influence_sorts):

            modify_num = len(influence_sort)
            sliced_influence = influence_sort[:modify_num]

            # slicing the influence function
            sliced_influence_idx_list = [ [] for _ in range(FL_params.data_classes)]
            for idx in sliced_influence:
                data = all_client_dataloader_original[ii_idx].dataset[idx]
                label = data[1]
                sliced_influence_idx_list[label].append(idx)

            all_sliced_influence_idx_lists.append(sliced_influence_idx_list)
            
        
        # reconstruct the attack dataset
        out_dataloader = list()
        out_result = list()
        for ii_idx,sliced_influence_idx_list in enumerate(all_sliced_influence_idx_lists):
            
            # find the index of the sample to be modified
            modify_indices = list()
            change_class_num = list()
                
            label_num = 0
            for idx in sliced_influence_idx_list[FL_params.triggerToClass]:
                modify_indices.append(idx)
                label_num += 1

                if len(modify_indices) >= single_client_max_num:
                    break
            # Record the modification result of each client
            change_class_num.append( ("Class-"+str(FL_params.triggerToClass),str(label_num)+"/"+str(single_client_max_num)) )

            dataset_new = CustomDatasetWithNarcissus(all_client_dataloader_original[ii_idx].dataset, modify_indices, FL_params.trigger)
            out_dataloader.append(DataLoader(dataset_new, all_client_dataloader_original[ii_idx].batch_size, shuffle=True, **kwargs))                        

            result_dict = {"change_index":modify_indices,"change_class_num":change_class_num}
            out_result.append(copy.deepcopy([str(FL_params.selected_clients[FL_params.attack_clients_idx[ii_idx]]),result_dict]))

            print("client_idx:",out_result[-1][0],"-----","change number:",result_dict["change_class_num"],"-----","total number:",len(result_dict["change_index"]))


        return out_dataloader, out_result


        
    else:
        raise ValueError(f'No such method in influence, please check it! Only {all_methods}')



def CustomDatasetWithNarcissus(dataset, modify_indices, trigger, transform=None):


    poison_train_target = poison_image(dataset,modify_indices,trigger.cpu(),transform)

    return poison_train_target


