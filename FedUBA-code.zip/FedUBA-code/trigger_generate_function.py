import torch
import tqdm

from torch.utils.data import Subset

from models import *

import os

import random

import numpy as np

from utils import *

from Fed_model_initiation import model_init

from Fed_data_preprocess import data_set_for_attack, data_set_outter

random_seed = 0
np.random.seed(random_seed)
random.seed(random_seed)
torch.manual_seed(random_seed)


criterion = torch.nn.CrossEntropyLoss()


def trigger_generate(FL_params):
    
    device = FL_params.device

    #Radius of the L-inf ball
    l_inf_r = FL_params.trigger_limit

    #Model for generating surrogate model and trigger
    surrogate_model = model_init(FL_params.data_name+"_outter").cuda()
    generating_model = model_init(FL_params.data_name+"_outter").cuda()


    #Surrogate model training epochs
    surrogate_epochs = 100


    #Learning rate for poison-warm-up
    generating_lr_warmup = 0.001
    warmup_round = 5

    #Learning rate for trigger generating
    generating_lr_tri = 0.1      
    gen_round = 100


    #Training batch size
    train_batch_size = FL_params.local_batch_size

    #The model for adding the noise
    patch_mode = 'add'

    # target class
    lab = FL_params.triggerToClass


    # Trigger noise path
    noise_path = f'./trigger_noise/trigger_{FL_params.data_name}.npy'

    # Check if the noise file exists
    if os.path.exists(noise_path) and not FL_params.if_train:
        noise_npy = np.load(noise_path)
        best_noise = torch.from_numpy(noise_npy).cuda()
        print('Noise loaded!')

    else:
        
        # Load the dataset
        ori_train = data_set_for_attack(FL_params)
        outter_trainset, _ = data_set_outter(FL_params.data_name)

        # Outter train dataset
        train_label = [get_labels(ori_train)[x] for x in range(len(get_labels(ori_train)))]

        # Inner train dataset
        train_target_list = list(np.where(np.array(train_label)==lab)[0])
        train_target = Subset(ori_train,train_target_list)


        concoct_train_dataset = concoct_dataset(train_target,outter_trainset,FL_params.data_name=='CIFAR10')

        surrogate_loader = torch.utils.data.DataLoader(concoct_train_dataset, batch_size=train_batch_size, shuffle=True)

        poi_warm_up_loader = torch.utils.data.DataLoader(sur_target_dataset(train_target,len(outter_trainset.classes)), batch_size=train_batch_size, shuffle=True)

        trigger_gen_loaders = torch.utils.data.DataLoader(sur_target_dataset(train_target,len(outter_trainset.classes)), batch_size=train_batch_size, shuffle=True)

        #Noise initialization
        noise_size = ori_train[0][0].shape[-1]
        noise_channel = ori_train[0][0].shape[0]
        noise = torch.zeros((1, noise_channel, noise_size, noise_size), device=device)

        surrogate_model = surrogate_model
        criterion = torch.nn.CrossEntropyLoss()
        surrogate_opt = torch.optim.SGD(params=surrogate_model.parameters(), lr=0.1, momentum=0.9, weight_decay=5e-4)
        surrogate_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(surrogate_opt, T_max=surrogate_epochs)

        # treining the surrogate model
        save_path = './checkpoint/surrogate_pretrain_' + f'{FL_params.data_name}_' + str(surrogate_epochs) +'.pth'
        # Load the surrogate model if it exists
        if os.path.exists(save_path) and not FL_params.if_train:
            surrogate_model.load_state_dict(torch.load(save_path))
            print('Surrogate model loaded!')
        else:
            print('Training the surrogate model')
            loss_history = []
            acc_history = []
            for epoch in range(0, surrogate_epochs):
                surrogate_model.train()
                loss_list = []
                acc_list = []
                for images, labels in surrogate_loader:
                    images, labels = images.cuda(), labels.cuda()
                    surrogate_opt.zero_grad()
                    outputs = surrogate_model(images)
                    loss = criterion(outputs, labels)
                    loss.backward()
                    loss_list.append(float(loss.data))
                    
                    _, predicted = torch.max(outputs.data, 1)
                    acc = (predicted == labels).sum().item()/labels.size(0)
                    acc_list.append(acc)

                    surrogate_opt.step()
                surrogate_scheduler.step()
                ave_loss = np.average(np.array(loss_list))
                ave_acc = np.average(np.array(acc_list))
                print('Epoch:%d, Loss: %.03f, Acc: %0.03f' % (epoch, ave_loss, ave_acc))

                loss_history.append(ave_loss)
                acc_history.append(ave_acc)
            #Save the surrogate model
            torch.save(surrogate_model.state_dict(),save_path)


        #Prepare models and optimizers for poi_warm_up training
        poi_warm_up_model = generating_model
        poi_warm_up_model.load_state_dict(surrogate_model.state_dict())


        poi_warm_up_opt = torch.optim.RAdam(params=poi_warm_up_model.parameters(), lr=generating_lr_warmup)

        #Poi_warm_up stage
        poi_warm_up_model.train()
        for param in poi_warm_up_model.parameters():
            param.requires_grad = True

        #Training the surrogate model
        for epoch in range(0, warmup_round):
            poi_warm_up_model.train()
            loss_list = []
            for images, labels in poi_warm_up_loader:
                images, labels = images.cuda(), labels.cuda()
                poi_warm_up_model.zero_grad()
                poi_warm_up_opt.zero_grad()
                outputs = poi_warm_up_model(images)
                loss = criterion(outputs, labels)
                loss.backward(retain_graph = True)
                loss_list.append(float(loss.item()))
                poi_warm_up_opt.step()
            ave_loss = np.average(np.array(loss_list))
            print('Epoch:%d, Loss: %e' % (epoch, ave_loss))

    

        # Trigger generating stage
        for param in poi_warm_up_model.parameters():
            param.requires_grad = False
        
        loss_history = []
        acc_history = []

        batch_pert = torch.autograd.Variable(noise.cuda(), requires_grad=True)
        batch_opt = torch.optim.RAdam(params=[batch_pert],lr=generating_lr_tri)
        trigger_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(batch_opt, T_max=gen_round)
        for minmin in tqdm.tqdm(range(gen_round)):
            loss_list = []
            total_clean = 0
            correct_clean = 0
            for images, labels in trigger_gen_loaders:
                images, labels = images.cuda(), labels.cuda()
                new_images = torch.clone(images)

                clamp_batch_pert = limit_noise(batch_pert,l_inf_r*2,scale_flag=False)
                new_images = torch.clamp(apply_noise_patch(clamp_batch_pert,new_images.clone(),mode=patch_mode),-1,1)
                per_logits = poi_warm_up_model.forward(new_images)
                loss = criterion(per_logits, labels)
                loss_regu = torch.mean(loss)
                batch_opt.zero_grad()
                loss_list.append(float(loss_regu.data))

                _, predicted = torch.max(per_logits.data, 1)
                total_clean += labels.size(0)
                correct_clean += (predicted == labels).sum().item()

                loss_regu.backward(retain_graph = True)
                batch_opt.step()
            trigger_scheduler.step()
            ave_loss = np.average(np.array(loss_list))
            ave_grad = np.sum(abs(batch_pert.grad).detach().cpu().numpy())

            if ave_grad == 0:
                break
            loss_history.append(ave_loss)
            acc_history.append(correct_clean / total_clean)

        noise = limit_noise(batch_pert,l_inf_r*2,scale_flag=False)
        best_noise = noise.clone().detach().cpu()
        print('Noise max val:',noise.max())

        np.save(noise_path, best_noise)

    return best_noise


def limit_noise(noise,noise_limit,scale_flag=True):
    #Noise limitation
    if scale_flag == True:
        current_inf_norm = np.max(np.abs(noise.detach().cpu().numpy()))
        if current_inf_norm > noise_limit:
            scale = noise_limit / current_inf_norm
            noise = noise * scale
        return noise
    else:
        return torch.clamp(noise,-noise_limit,noise_limit)
    


def custom_collate_fn(batch):

    images = []
    labels = []
    
    for item in batch:
        images.append(item[0])
        
        
        if isinstance(item[1], torch.Tensor):
            labels.append(item[1])
        else:
            labels.append(torch.tensor(item[1]))
    
    images = torch.stack(images, 0)
    labels = torch.stack(labels, 0)
    
    return images, labels

